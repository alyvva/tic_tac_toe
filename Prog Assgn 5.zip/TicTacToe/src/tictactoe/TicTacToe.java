/*
//********************************************************************************
// STUDENT NAME:  [Alyssa Williams]
// FIU EMAIL: [awill320@fiu.edu]
// CLASS: COP 2210 – [FALL, 2017]
// ASSIGNMENT # [5]
// DATE: [12/9/17]
//
// I hereby swear and affirm that this work is solely my own, and not the work 
// or the derivative of the work of someone else, except as outlined in the 
// assignment instructions.
//********************************************************************************

 */
package tictactoe;

import javax.swing.JOptionPane;

/**
 *
 * @author alyvv
 */
public class TicTacToe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        TicTacToeGame game = new TicTacToeGame();
             
String user = JOptionPane.showInputDialog(null, "Enter your name..");
    game.setuserName(user); //User will enter their name.
    
    JOptionPane.showMessageDialog(null, "Welcome to tic tac toe " 
            + user + "..enjoy!"); //Greeting including User's name.
    
    game.printBoard(); //Calls printBoard method from other class.
    game.firstTurn();  //Calls firstTurn method from other class.
        
    }
    
}
