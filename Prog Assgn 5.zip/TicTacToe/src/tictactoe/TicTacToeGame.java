/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe;

import javax.swing.JOptionPane;
import java.util.Random;

/**
 *
 * @author alyvv
 */
public class TicTacToeGame {

    String userName; //Receive user's name.

    String getuserName() {
        return userName;
    }

    void setuserName(String user) {
        userName = user;
    }

    /*Creates array object called gameBoard and gives it length 3 for i,j.
/Private variable playerMark represents the 'X' or 'O' on tic tac toe board.
/Random object created to generate who goes first in game.
/row/column variables used within the CPU/Player Mark methods. 
/boolean variable made to switch turns within game.
     */
    private char[][] gameBoard = new char[3][3];
    private char playerMark;
    Random r = new Random();
    private int row;
    private int column;
    private int row1;
    private int column1;
    private boolean switchPlayer;

    public TicTacToeGame() {
//Contructor for setting up game board. 
        for (int i = 0; i < gameBoard.length; i++) {
            for (int j = 0; j < gameBoard[i].length; j++) {
                gameBoard[i][j] = '-';
            }
        }

    }

    public void initializeBoard() {
        //This method initializes tic tac toe board to empty spaces.
        for (int i = 0; i < gameBoard.length; i++) {
            for (int j = 0; j < gameBoard[i].length; j++) {
                gameBoard[i][j] = '-';

            }
        }
    }

    public void printBoard() {
        //This method prints out empty tic tac toe board.
        System.out.println("------------");
        for (int i = 0; i < 3; i++) {
            System.out.print("|");
            for (int j = 0; j < 3; j++) {
                System.out.print(gameBoard[i][j] + " | ");
            }
            System.out.println();
            System.out.println("------------");
        }
    }

    public void firstTurn() {
//Method determines the first turn through random selection. Then calls upon CPU/PlayerMark methods.
        int firstturn = r.nextInt(2);
        if (firstturn == 1) {
            JOptionPane.showMessageDialog(null, "The computer "
                    + "decided you are first to go.");
            PlayerMark();
        } else {
            JOptionPane.showMessageDialog(null, "The computer decided "
                    + "to go first.");
            CPUmark();
        }
    }

    public void CPUmark() {
//Method randomly puts a CPU mark on tic tac toe board if equal to '-' in one of 
//any of the 9 slots empty to '-'. 
        row = r.nextInt(3);
        column = r.nextInt(3);
        if (gameBoard[row][column] == '-') {
            gameBoard[row][column] = 'O';
            printBoard();
            checkRowsForWin();
            checkColumnsForWin();
            checkDiagonalsForWin();
            tie();
            switchPlayer = false;
            switchTurns();
        } else {
            CPUmark();

        }

    }

    public void PlayerMark() {
//Method for player to type in what row and column they want to place their mark.
        row1 = Integer.parseInt(JOptionPane.showInputDialog("Enter a row (0-2) "
                + "to place an X mark."));
        column1 = Integer.parseInt(JOptionPane.showInputDialog("Enter a column (0-2) "
                + "to place an X mark."));
        if (gameBoard[row1][column1] == '-') {
            gameBoard[row1][column1] = 'X';
            printBoard();
            checkRowsForWin();
            checkColumnsForWin();
            checkDiagonalsForWin();
            tie();
            switchPlayer = true;
            switchTurns();

        } else {
            PlayerMark();

        }

    }

    public void switchTurns() {
        //Switch turn method is set up as a boolean condition that lets CPU go if equal
        // to true and lets the player go if equal to false. Called upon in CPU/PlayerMark methods. 
        if (switchPlayer == true) {
            CPUmark();
        } else if (switchPlayer == false) {
            PlayerMark();
        }
    }

    private void checkRowsForWin() {
        //Checks rows for win as long as they are not equal to empty space '-'.

        for (int i = 0; i < gameBoard.length; i++) {
            if ((gameBoard[i][0] == gameBoard[i][1]) && (gameBoard[i][1] == gameBoard[i][2]) && (gameBoard[i][2] == gameBoard[i][0])
                    && (gameBoard[i][0] != '-') && (gameBoard[i][1] != '-') && (gameBoard[i][2] != '-')) {
                playAgain();
            }
        }
    }

    private void checkColumnsForWin() {
        //Checks columns for win as long as they are not equal to empty space '-'.

        for (int i = 0; i < gameBoard.length; i++) {
            if ((gameBoard[0][i] == gameBoard[1][i]) && (gameBoard[1][i] == gameBoard[2][i]) && (gameBoard[2][i] == gameBoard[0][i])
                    && (gameBoard[0][i] != '-') && (gameBoard[1][i] != '-') && (gameBoard[2][i] != '-')) {
                playAgain();
            }
        }
    }

    private void checkDiagonalsForWin() {
        //Checks diagonals for win as long as they are not equal to empty space '-'.

        if ((gameBoard[0][0] == gameBoard[1][1]) && (gameBoard[1][1] == gameBoard[2][2]) && 
                (gameBoard[0][0] == gameBoard[2][2]) && (gameBoard[0][0] != '-') && (gameBoard[1][1] != '-') && (gameBoard[2][2] != '-')) {
            playAgain();
        } else if ((gameBoard[0][2] == gameBoard[1][1]) && (gameBoard[1][1] == gameBoard[2][0])
                && (gameBoard[0][2] == gameBoard[2][0]) && (gameBoard[0][2] != '-') && (gameBoard[2][0] != '-') && (gameBoard[1][1] != '-')) {
            playAgain();
        }
    } 

    private void playAgain() {
        //Asks user if they want to play again. If yes, will call the firstTurn method to restart game.
        //If no, then shows an exit message and exits the game. 
        String choice = JOptionPane.showInputDialog(null, "Do you want to play again? Type "
                + "'yes' or 'no'");
        if (choice.equals("yes")) {
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    gameBoard[i][j] = '-';
                }
            }
            firstTurn();
        } else {
            JOptionPane.showMessageDialog(null, "Thanks for playing.");
            System.exit(0);
        }

    }

    private void tie() {
        //Measures gameboard for ties! Then asks user if they want to play again. 
        if ((gameBoard[0][0] != '-') && (gameBoard[0][1] != '-') && (gameBoard[0][2] != '-') && 
                (gameBoard[1][0] != '-') && (gameBoard[1][1] != '-') && (gameBoard[1][2] != '-')
                && (gameBoard[2][0] != '-') && (gameBoard[2][1] != '-') && (gameBoard[2][2] != '-')) {
            JOptionPane.showMessageDialog(null, "It's a tie.");
            playAgain();
        } else {

        }
    }

}
